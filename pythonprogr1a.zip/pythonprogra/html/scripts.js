document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const originalTextElem = document.getElementById('original-text');
    const noTerminalesElem = document.getElementById('no-terminales');
    const terminalesElem = document.getElementById('terminales');
    const produccionesElem = document.getElementById('producciones');
    const sinRecursividadElem = document.getElementById('sin-recursividad');
    const primeroElem = document.getElementById('primero');
    const siguienteElem = document.getElementById('siguiente');
    const tablaAnalisisElem = document.getElementById('tabla-analisis');

    dropZone.addEventListener('click', () => fileInput.click());
    dropZone.addEventListener('dragover', (event) => {
        event.preventDefault();
        dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));

    dropZone.addEventListener('drop', (event) => {
        event.preventDefault();
        dropZone.classList.remove('dragover');
        const file = event.dataTransfer.files[0];
        if (file) {
            handleFile(file);
        }
    });

    fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            handleFile(file);
        }
    });

    function handleFile(file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            const text = event.target.result;
            processGrammar(text);
        };
        reader.readAsText(file);
    }

    function processGrammar(text) {
        const lines = text.split('\n');
        const noTerminales = new Set();
        const terminales = new Set();
        const producciones = [];

        lines.forEach(line => {
            const parts = line.trim().split(':');
            const noTerminal = parts[0].trim();
            noTerminales.add(noTerminal);
            const prods = parts[1].split('|');
            prods.forEach(prod => {
                const elementos = prod.split("'");
                const produccionLimpia = elementos.map((elem, i) => i % 2 === 0 ? elem : elem.trim()).join('');
                producciones.push({ noTerminal, produccion: produccionLimpia });
                elementos.forEach((elem, i) => {
                    if (i % 2 === 1 && elem.trim() !== '!') {
                        terminales.add(elem.trim());
                    }
                });
            });
        });

        originalTextElem.textContent = text;
        noTerminalesElem.textContent = Array.from(noTerminales).sort().join('\n');
        terminalesElem.textContent = Array.from(terminales).sort().join('\n');
        produccionesElem.textContent = producciones.map(p => `${p.noTerminal} : ${p.produccion}`).join('\n');

        const gramSinRec = eliminarRecursividadIzquierda(producciones);
        sinRecursividadElem.textContent = gramSinRec.map(p => `${p.noTerminal} : ${p.produccion}`).join('\n');

        const primero = calcularPrimero(gramSinRec);
        primeroElem.textContent = formatSetDict(primero);

        const siguiente = calcularSiguiente(gramSinRec, primero);
        siguienteElem.textContent = formatSetDict(siguiente);

        const tablaAnalisisSintactico = calcularTablaAnalisisSintactico(gramSinRec, primero, siguiente);
        tablaAnalisisElem.textContent = formatTablaAnalisis(tablaAnalisisSintactico, Array.from(noTerminales).sort(), Array.from(terminales).sort());
    }

    function eliminarRecursividadIzquierda(producciones) {
        const noTerminales = Array.from(new Set(producciones.map(p => p.noTerminal))).sort();
        const gramSinRec = [];

        const produccionesDict = {};
        noTerminales.forEach(nt => produccionesDict[nt] = []);
        producciones.forEach(p => produccionesDict[p.noTerminal].push(p.produccion));

        noTerminales.forEach((Ai, i) => {
            noTerminales.slice(0, i).forEach(Aj => {
                const nuevasProducciones = [];
                produccionesDict[Ai].forEach(prod => {
                    if (prod.startsWith(Aj)) {
                        produccionesDict[Aj].forEach(prodAj => {
                            nuevasProducciones.push(prodAj + prod.slice(Aj.length));
                        });
                    } else {
                        nuevasProducciones.push(prod);
                    }
                });
                produccionesDict[Ai] = nuevasProducciones;
            });

            const recursivas = produccionesDict[Ai].filter(prod => prod.startsWith(Ai));
            const noRecursivas = produccionesDict[Ai].filter(prod => !prod.startsWith(Ai));

            if (recursivas.length > 0) {
                const AiPrime = Ai + '!';
                produccionesDict[Ai] = noRecursivas.map(prod => prod + AiPrime);
                produccionesDict[AiPrime] = recursivas.map(prod => prod.slice(Ai.length) + AiPrime).concat('e');
                noTerminales.push(AiPrime);
                gramSinRec.push(...produccionesDict[AiPrime].map(prod => ({ noTerminal: AiPrime, produccion: prod })));
            }
            gramSinRec.push(...produccionesDict[Ai].map(prod => ({ noTerminal: Ai, produccion: prod })));
        });

        return gramSinRec;
    }

    function calcularPrimero(producciones) {
        const primero = {};
        const produccionesDict = {};
        producciones.forEach(p => {
            if (!produccionesDict[p.noTerminal]) {
                produccionesDict[p.noTerminal] = [];
            }
            produccionesDict[p.noTerminal].push(p.produccion);
        });

        function obtenerPrimero(symbol) {
            if (primero[symbol]) {
                return primero[symbol];
            }
            if (!symbol.match(/[A-Z]/)) {
                primero[symbol] = new Set([symbol]);
                return primero[symbol];
            }
            primero[symbol] = new Set();
            produccionesDict[symbol].forEach(prod => {
                if (prod === 'e') {
                    primero[symbol].add('e');
                } else {
                    for (const char of prod) {
                        const temp = obtenerPrimero(char);
                        primero[symbol] = new Set([...primero[symbol], ...temp].filter(x => x !== 'e'));
                        if (!temp.has('e')) break;
                    }
                }
            });
            return primero[symbol];
        }

        Object.keys(produccionesDict).forEach(nt => obtenerPrimero(nt));
        return primero;
    }

    function calcularSiguiente(producciones, primero) {
        const siguiente = {};
        const produccionesDict = {};
        producciones.forEach(p => {
            if (!produccionesDict[p.noTerminal]) {
                produccionesDict[p.noTerminal] = [];
            }
            produccionesDict[p.noTerminal].push(p.produccion);
        });

        const startSymbol = Object.keys(produccionesDict)[0];
        siguiente[startSymbol] = new Set(['$']);

        let updated;
        do {
            updated = false;
            Object.keys(produccionesDict).forEach(A => {
                produccionesDict[A].forEach(prod => {
                    const n = prod.length;
                    for (let i = 0; i < n; i++) {
                        if (prod[i].match(/[A-Z]/)) {
                            const B = prod[i];
                            const beta = prod.slice(i + 1);
                            const primeroBeta = obtenerPrimeroBeta(beta, primero);
                            const antesActualizacion = siguiente[B] ? siguiente[B].size : 0;
                            if (!siguiente[B]) siguiente[B] = new Set();
                            siguiente[B] = new Set([...siguiente[B], ...primeroBeta].filter(x => x !== 'e'));
                            if (primeroBeta.has('e') || beta.length === 0) {
                                siguiente[B] = new Set([...siguiente[B], ...siguiente[A]]);
                            }
                            if (siguiente[B].size > antesActualizacion) {
                                updated = true;
                            }
                        }
                    }
                });
            });
        } while (updated);

        return siguiente;
    }

    function obtenerPrimeroBeta(beta, primero) {
        const resultado = new Set();
        for (const b of beta) {
            if (b.match(/[A-Z]/)) {
                resultado.add(...primero[b].filter(x => x !== 'e'));
                if (!primero[b].has('e')) break;
            } else {
                resultado.add(b);
                break;
            }
        }
        if (beta.length === 0 || resultado.size === 0 || Array.from(resultado).every(x => primero[x].has('e'))) {
            resultado.add('e');
        }
        return resultado;
    }

    function calcularTablaAnalisisSintactico(producciones, primero, siguiente) {
        const tabla = {};
        const produccionesDict = {};
        producciones.forEach(p => {
            if (!produccionesDict[p.noTerminal]) {
                produccionesDict[p.noTerminal] = [];
            }
            produccionesDict[p.noTerminal].push(p.produccion);
        });

        Object.keys(produccionesDict).forEach(nt => {
            produccionesDict[nt].forEach(prod => {
                const primeroBeta = obtenerPrimeroBeta(prod, primero);
                primeroBeta.forEach(terminal => {
                    if (terminal !== 'e') {
                        if (!tabla[nt]) tabla[nt] = {};
                        tabla[nt][terminal] = prod;
                    }
                });
                if (primeroBeta.has('e')) {
                    siguiente[nt].forEach(terminal => {
                        if (!tabla[nt]) tabla[nt] = {};
                        tabla[nt][terminal] = 'e';
                    });
                }
            });
        });

        return tabla;
    }

    function formatSetDict(dict) {
        return Object.keys(dict).map(key => `${key}: {${Array.from(dict[key]).join(', ')}}`).join('\n');
    }

    function formatTablaAnalisis(tabla, noTerminales, terminales) {
        const header = `V\t${terminales.join('\t')}\n`;
        const rows = noTerminales.map(nt => {
            const row = terminales.map(t => tabla[nt] ? (tabla[nt][t] || '--') : '--').join('\t');
            return `${nt}\t${row}`;
        }).join('\n');
        return header + rows;
    }
});
