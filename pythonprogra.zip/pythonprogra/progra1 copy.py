import tkinter as tk
from tkinter import filedialog
from tkinterdnd2 import DND_FILES, TkinterDnD
from tkinter import ttk
from collections import defaultdict

def cargar_gramatica(file_path=None):
    if not file_path:
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
    if not file_path:
        return

    with open(file_path, 'r') as file:
        lines = file.readlines()

    no_terminales = set()
    terminales = set()
    producciones = []

    for line in lines:
        parts = line.strip().split(':')
        no_terminal = parts[0].strip()
        no_terminales.add(no_terminal)
        prods = parts[1].split('|')
        for prod in prods:
            elementos = prod.split("'")
            produccion_limpia = ''.join([elem if i % 2 == 0 else elem.strip() for i, elem in enumerate(elementos)])
            producciones.append((no_terminal, produccion_limpia))
            for i, elem in enumerate(elementos):
                if i % 2 == 1:
                    terminales.add(elem.strip())

    mostrar_gramatica(list(no_terminales), list(terminales))
    mostrar_texto_original(lines)
    mostrar_producciones(producciones)
    gram_sin_rec = eliminar_recursividad_izquierda(producciones)
    mostrar_gramatica_sin_recursividad(gram_sin_rec)
    mostrar_gramatica_sin_recursividad_label(gram_sin_rec)
    calcular_primero(gram_sin_rec)

def mostrar_gramatica(no_terminales, terminales):
    no_terminales.sort()
    terminales.sort()

    for widget in frame_no_terminales.winfo_children():
        widget.destroy()
    for widget in frame_terminales.winfo_children():
        widget.destroy()

    for no_terminal in no_terminales:
        label = tk.Label(frame_no_terminales, text=no_terminal, font=("Helvetica", 14))
        label.pack(anchor='w')

    for terminal in terminales:
        label = tk.Label(frame_terminales, text=terminal, font=("Helvetica", 14))
        label.pack(anchor='w')

def mostrar_texto_original(lines):
    text_original.delete(1.0, tk.END)
    for line in lines:
        text_original.insert(tk.END, line)
    text_original.config(height=min(len(lines), 10))  # Ajustar la altura según el contenido

def mostrar_producciones(producciones):
    for item in tree.get_children():
        tree.delete(item)

    for no_terminal, produccion in producciones:
        tree.insert('', 'end', values=(no_terminal, produccion))
    
    tree_frame.config(height=min(len(producciones) * 20, 200))  # Ajustar la altura según el contenido

def mostrar_gramatica_sin_recursividad(producciones):
    for item in tree_sin_recursividad.get_children():
        tree_sin_recursividad.delete(item)

    for no_terminal, produccion in producciones:
        tree_sin_recursividad.insert('', 'end', values=(no_terminal, produccion.replace("'", "!").replace("ε", "e").replace("->", ":")))
    
    tree_sin_rec_frame.config(height=min(len(producciones) * 20, 200))  # Ajustar la altura según el contenido

def mostrar_gramatica_sin_recursividad_label(producciones):
    result_label.config(state=tk.NORMAL)
    result_label.delete(1.0, tk.END)
    no_terminales_usados = set()
    for no_terminal, produccion in producciones:
        if no_terminal not in no_terminales_usados:
            if no_terminales_usados:
                result_label.insert(tk.END, "\n")
            result_label.insert(tk.END, f"{no_terminal}: {produccion}")
            no_terminales_usados.add(no_terminal)
        else:
            result_label.insert(tk.END, f" | {produccion}")
    result_label.config(state=tk.DISABLED)

def eliminar_recursividad_izquierda(producciones):
    # Ordenar los no terminales
    no_terminales = sorted(set([prod[0] for prod in producciones]))
    gram_sin_rec = []

    # Convertir producciones a un diccionario
    producciones_dict = {nt: [] for nt in no_terminales}
    for nt, prod in producciones:
        producciones_dict[nt].append(prod)

    # Aplicar el algoritmo
    for i in range(len(no_terminales)):
        Ai = no_terminales[i]
        for j in range(i):
            Aj = no_terminales[j]
            nuevas_producciones = []
            for prod in producciones_dict[Ai]:
                if prod.startswith(Aj):
                    for prod_Aj in producciones_dict[Aj]:
                        nuevas_producciones.append(prod_Aj + prod[len(Aj):])
                else:
                    nuevas_producciones.append(prod)
            producciones_dict[Ai] = nuevas_producciones
        # Eliminar recursividad inmediata por la izquierda
        recursivas = [prod for prod in producciones_dict[Ai] if prod.startswith(Ai)]
        no_recursivas = [prod for prod in producciones_dict[Ai] if not prod.startswith(Ai)]
        if recursivas:
            Ai_prime = Ai + "!"
            producciones_dict[Ai] = [prod + Ai_prime for prod in no_recursivas]
            producciones_dict[Ai_prime] = [prod[len(Ai):] + Ai_prime for prod in recursivas] + ['e']
            no_terminales.append(Ai_prime)
            gram_sin_rec.extend([(Ai_prime, prod) for prod in producciones_dict[Ai_prime]])
        gram_sin_rec.extend([(Ai, prod) for prod in producciones_dict[Ai]])

    return gram_sin_rec

def calcular_primero(producciones):
    primero = defaultdict(set)
    producciones_dict = defaultdict(list)
    for nt, prod in producciones:
        producciones_dict[nt].append(prod)

    def obtener_primero(symbol):
        if symbol in primero:
            return primero[symbol]
        if not symbol.isupper():  # Es un terminal
            primero[symbol].add(symbol)
            return primero[symbol]
        for prod in producciones_dict[symbol]:
            if prod == 'e':
                primero[symbol].add('e')
            else:
                for char in prod:
                    temp = obtener_primero(char)
                    primero[symbol].update(temp - {'e'})
                    if 'e' not in temp:
                        break
                else:
                    primero[symbol].add('e')
        return primero[symbol]

    for nt in list(producciones_dict):
        obtener_primero(nt)

    mostrar_primero(primero)

def mostrar_primero(primero):
    primero_text.config(state=tk.NORMAL)
    primero_text.delete(1.0, tk.END)
    for nt in primero:
        primero_text.insert(tk.END, f"PRIMERO({nt}): {', '.join(sorted(primero[nt]))}\n")
    primero_text.config(state=tk.DISABLED)

def on_drop(event):
    file_path = event.data
    if file_path.startswith('{') and file_path.endswith('}'):
        file_path = file_path[1:-1]
    cargar_gramatica(file_path)

# Configuración de la ventana principal
root = TkinterDnD.Tk()
root.title("Gramática")
root.state('zoomed')  # Maximiza la ventana al iniciar

# Configurar el grid para que sea responsivo
root.columnconfigure(0, weight=1)
root.columnconfigure(1, weight=1)
root.columnconfigure(2, weight=1)
root.columnconfigure(3, weight=1)
root.columnconfigure(4, weight=1)
root.rowconfigure(0, weight=1)
root.rowconfigure(1, weight=1)
root.rowconfigure(2, weight=1)
root.rowconfigure(3, weight=1)

# Encabezados
label_texto_original = tk.Label(root, text="Texto Original", font=("Helvetica", 16))
label_texto_original.grid(row=0, column=0, padx=10, pady=10)

label_no_terminales = tk.Label(root, text="No Terminales", font=("Helvetica", 16))
label_no_terminales.grid(row=0, column=1, padx=10, pady=10)

label_terminales = tk.Label(root, text="Terminales", font=("Helvetica", 16))
label_terminales.grid(row=0, column=2, padx=10, pady=10)

label_producciones = tk.Label(root, text="Producciones", font=("Helvetica", 16))
label_producciones.grid(row=0, column=3, padx=10, pady=10)

# Widgets en la primera fila
text_original = tk.Text(root, height=10, width=50, font=("Helvetica", 14))
text_original.grid(row=1, column=0, padx=10, pady=10, sticky='nsew')

frame_no_terminales = tk.Frame(root, padx=10, pady=10)
frame_no_terminales.grid(row=1, column=1, sticky='nsew')

frame_terminales = tk.Frame(root, padx=10, pady=10)
frame_terminales.grid(row=1, column=2, sticky='nsew')

frame_producciones = tk.Frame(root, padx=10, pady=10)
frame_producciones.grid(row=1, column=3, sticky='nsew')

# Crear la tabla para las producciones dentro de un frame con scrollbar
tree_frame = tk.Frame(frame_producciones)
tree_frame.pack(fill='both', expand=True)
tree_scroll = tk.Scrollbar(tree_frame)
tree_scroll.pack(side='right', fill='y')

tree = ttk.Treeview(tree_frame, columns=("No Terminal", "Producción"), show='headings', yscrollcommand=tree_scroll.set)
tree.heading("No Terminal", text="No Terminal")
tree.heading("Producción", text="Producción")
tree.column("No Terminal", anchor='center', width=100)
tree.column("Producción", anchor='center', width=400)
tree.pack(fill='both', expand=True)
tree_scroll.config(command=tree.yview)

# Encabezado para la segunda fila
label_resultado = tk.Label(root, text="Gramática sin Recursividad por la Izquierda", font=("Helvetica", 16))
label_resultado.grid(row=2, column=0, columnspan=6, padx=10, pady=10)

# Frame para la gramática sin recursividad
tree_sin_rec_frame = tk.Frame(root)
tree_sin_rec_frame.grid(row=3, column=0, columnspan=2, sticky='nsew')
tree_sin_rec_scroll = tk.Scrollbar(tree_sin_rec_frame)
tree_sin_rec_scroll.pack(side='right', fill='y')
tree_sin_recursividad = ttk.Treeview(tree_sin_rec_frame, columns=("No Terminal", "Producción"), show='headings', yscrollcommand=tree_sin_rec_scroll.set)
tree_sin_recursividad.heading("No Terminal", text="No Terminal")
tree_sin_recursividad.heading("Producción", text="Producción")
tree_sin_recursividad.column("No Terminal", anchor='center', width=100)
tree_sin_recursividad.column("Producción", anchor='center', width=400)
tree_sin_recursividad.pack(fill='both', expand=True)
tree_sin_rec_scroll.config(command=tree_sin_recursividad.yview)

# Label para el resultado de la gramática sin recursividad
frame_resultado_label = tk.Frame(root)
frame_resultado_label.grid(row=3, column=2, columnspan=2, sticky='nsew')
result_label = tk.Text(frame_resultado_label, height=10, font=("Helvetica", 14))
result_label.pack(fill='both', expand=True)

# Frame y widget para PRIMERO
frame_primero = tk.Frame(root)
frame_primero.grid(row=3, column=4, columnspan=2, sticky='nsew')
primero_text = tk.Text(frame_primero, height=10, font=("Helvetica", 14))
primero_text.pack(fill='both', expand=True)

button_cargar = tk.Button(root, text="Cargar Gramática", command=cargar_gramatica, font=("Helvetica", 14))
button_cargar.grid(row=4, column=0, columnspan=6, pady=10)

# Habilitar la funcionalidad de arrastrar y soltar
root.drop_target_register(DND_FILES)
root.dnd_bind('<<Drop>>', on_drop)

root.mainloop()