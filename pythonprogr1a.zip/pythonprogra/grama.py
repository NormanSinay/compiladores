import wx
import wx.grid
from collections import defaultdict

class MainWindow(wx.Frame):
    def __init__(self, parent, title):
        super(MainWindow, self).__init__(parent, title=title, size=(1200, 800))

        self.panel = wx.Panel(self)
        self.sizer = wx.BoxSizer(wx.VERTICAL)

        self.button_cargar = wx.Button(self.panel, label="Cargar Gramática")
        self.button_cargar.Bind(wx.EVT_BUTTON, self.on_load_grammar)
        self.sizer.Add(self.button_cargar, 0, wx.ALL | wx.EXPAND, 5)

        self.resultados_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer.Add(self.resultados_sizer, 1, wx.EXPAND)

        # Div para Texto Original
        self.frame_texto_original = wx.BoxSizer(wx.VERTICAL)
        self.resultados_sizer.Add(self.frame_texto_original, 1, wx.EXPAND)

        # Div para Vectores
        self.frame_vectores = wx.BoxSizer(wx.VERTICAL)
        self.resultados_sizer.Add(self.frame_vectores, 1, wx.EXPAND)

        self.frame_no_terminales = wx.BoxSizer(wx.VERTICAL)
        self.frame_vectores.Add(self.frame_no_terminales, 1, wx.EXPAND)

        self.frame_terminales = wx.BoxSizer(wx.VERTICAL)
        self.frame_vectores.Add(self.frame_terminales, 1, wx.EXPAND)

        # Div para Producciones
        self.frame_producciones = wx.BoxSizer(wx.VERTICAL)
        self.resultados_sizer.Add(self.frame_producciones, 1, wx.EXPAND)

        # Sección adicional para gramática sin recursividad y tablas
        self.gramatica_tablas_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer.Add(self.gramatica_tablas_sizer, 1, wx.EXPAND)

        self.frame_sin_recursividad = wx.BoxSizer(wx.VERTICAL)
        self.gramatica_tablas_sizer.Add(self.frame_sin_recursividad, 1, wx.EXPAND)

        self.frame_primero = wx.BoxSizer(wx.VERTICAL)
        self.gramatica_tablas_sizer.Add(self.frame_primero, 1, wx.EXPAND)

        self.frame_siguiente = wx.BoxSizer(wx.VERTICAL)
        self.gramatica_tablas_sizer.Add(self.frame_siguiente, 1, wx.EXPAND)

        self.frame_tabla_analisis_sintactico = wx.BoxSizer(wx.VERTICAL)
        self.gramatica_tablas_sizer.Add(self.frame_tabla_analisis_sintactico, 1, wx.EXPAND)

        self.panel.SetSizerAndFit(self.sizer)
        self.Bind(wx.EVT_DROP_FILES, self.on_drop)

        self.SetDropTarget(FileDropTarget(self))

        self.Show()

    def on_load_grammar(self, event):
        with wx.FileDialog(self, "Open Grammar file", wildcard="Text files (*.txt)|*.txt",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as fileDialog:

            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return     # the user changed their mind

            # Proceed loading the file chosen by the user
            pathname = fileDialog.GetPath()
            try:
                with open(pathname, 'r') as file:
                    lines = file.readlines()
                self.process_grammar(lines)
            except IOError:
                wx.LogError("Cannot open file '%s'." % pathname)

    def process_grammar(self, lines):
        no_terminales = set()
        terminales = set()
        producciones = []

        for line in lines:
            parts = line.strip().split(':')
            no_terminal = parts[0].strip()
            no_terminales.add(no_terminal)
            prods = parts[1].split('|')
            for prod in prods:
                elementos = prod.split("'")
                produccion_limpia = ''.join([elem if i % 2 == 0 else elem.strip() for i, elem in enumerate(elementos)])
                producciones.append((no_terminal, produccion_limpia))
                for i, elem in enumerate(elementos):
                    if i % 2 == 1 and elem.strip() != '!':
                        terminales.add(elem.strip())

        self.mostrar_gramatica(list(no_terminales), list(terminales))
        self.mostrar_texto_original(lines)
        self.mostrar_producciones(producciones)
        gram_sin_rec = self.eliminar_recursividad_izquierda(producciones)
        self.mostrar_gramatica_sin_recursividad(gram_sin_rec)
        primero = self.calcular_primero(gram_sin_rec)
        siguiente = self.calcular_siguiente(gram_sin_rec, primero)
        tabla_analisis_sintactico = self.calcular_tabla_analisis_sintactico(gram_sin_rec, primero, siguiente)
        self.mostrar_tabla_analisis_sintactico(tabla_analisis_sintactico, list(no_terminales), list(terminales))

    def mostrar_gramatica(self, no_terminales, terminales):
        no_terminales.sort()
        terminales.sort()

        for child in self.frame_no_terminales.GetChildren():
            child.Destroy()
        for child in self.frame_terminales.GetChildren():
            child.Destroy()

        for no_terminal in no_terminales:
            label = wx.StaticText(self.panel, label=no_terminal)
            self.frame_no_terminales.Add(label, 0, wx.ALL, 5)

        for terminal in terminales:
            label = wx.StaticText(self.panel, label=terminal)
            self.frame_terminales.Add(label, 0, wx.ALL, 5)

        self.Layout()

    def mostrar_texto_original(self, lines):
        for child in self.frame_texto_original.GetChildren():
            child.Destroy()
        for line in lines:
            label = wx.StaticText(self.panel, label=line.strip())
            self.frame_texto_original.Add(label, 0, wx.ALL, 5)
        self.Layout()

    def mostrar_producciones(self, producciones):
        for child in self.frame_producciones.GetChildren():
            child.Destroy()
        grid = wx.grid.Grid(self.panel)
        grid.CreateGrid(len(producciones), 2)
        grid.SetColLabelValue(0, "No Terminal")
        grid.SetColLabelValue(1, "Producción")

        for i, (no_terminal, produccion) in enumerate(producciones):
            grid.SetCellValue(i, 0, no_terminal)
            grid.SetCellValue(i, 1, produccion)

        self.frame_producciones.Add(grid, 1, wx.EXPAND | wx.ALL, 5)
        self.Layout()

    def mostrar_gramatica_sin_recursividad(self, producciones):
        for child in self.frame_sin_recursividad.GetChildren():
            child.Destroy()
        grid = wx.grid.Grid(self.panel)
        grid.CreateGrid(len(producciones), 2)
        grid.SetColLabelValue(0, "V")
        grid.SetColLabelValue(1, "Producciones")

        for i, (no_terminal, produccion) in enumerate(producciones):
            grid.SetCellValue(i, 0, no_terminal)
            grid.SetCellValue(i, 1, produccion.replace("'", "").replace("ε", "e"))

        self.frame_sin_recursividad.Add(grid, 1, wx.EXPAND | wx.ALL, 5)
        self.Layout()

    def eliminar_recursividad_izquierda(self, producciones):
        no_terminales = sorted(set([prod[0] for prod in producciones]))
        gram_sin_rec = []

        producciones_dict = {nt: [] for nt in no_terminales}
        for nt, prod in producciones:
            producciones_dict[nt].append(prod)

        for i in range(len(no_terminales)):
            Ai = no_terminales[i]
            for j in range(i):
                Aj = no_terminales[j]
                nuevas_producciones = []
                for prod in producciones_dict[Ai]:
                    if prod.startswith(Aj):
                        for prod_Aj in producciones_dict[Aj]:
                            nuevas_producciones.append(prod_Aj + prod[len(Aj):])
                    else:
                        nuevas_producciones.append(prod)
                producciones_dict[Ai] = nuevas_producciones
            recursivas = [prod for prod in producciones_dict[Ai] if prod.startswith(Ai)]
            no_recursivas = [prod for prod in producciones_dict[Ai] if not prod.startswith(Ai)]
            if recursivas:
                Ai_prime = Ai + "!"
                producciones_dict[Ai] = [prod + Ai_prime for prod in no_recursivas]
                producciones_dict[Ai_prime] = [prod[len(Ai):] + Ai_prime for prod in recursivas] + ['e']
                no_terminales.append(Ai_prime)
                gram_sin_rec.extend([(Ai_prime, prod) for prod in producciones_dict[Ai_prime]])
            gram_sin_rec.extend([(Ai, prod) for prod in producciones_dict[Ai]])

        return gram_sin_rec

    def calcular_primero(self, producciones):
        primero = defaultdict(set)
        producciones_dict = defaultdict(list)
        for nt, prod in producciones:
            producciones_dict[nt].append(prod)

        def obtener_primero(symbol):
            if symbol in primero:
                return primero[symbol]
            if not symbol.isupper():
                primero[symbol].add(symbol)
                return primero[symbol]
            for prod in producciones_dict[symbol]:
                if prod == 'e':
                    primero[symbol].add('e')
                else:
                    for char in prod:
                        temp = obtener_primero(char)
                        primero[symbol].update(temp - {'e'})
                        if 'e' not in temp:
                            break
                    else:
                        primero[symbol].add('e')
            return primero[symbol]

        for nt in list(producciones_dict):
            obtener_primero(nt)
        self.mostrar_primero(primero, producciones_dict)
        return primero

    def mostrar_primero(self, primero, producciones_dict):
        for child in self.frame_primero.GetChildren():
            child.Destroy()
        grid = wx.grid.Grid(self.panel)
        grid.CreateGrid(len(primero), 2)
        grid.SetColLabelValue(0, "V")
        grid.SetColLabelValue(1, "Terminales")

        for i, nt in enumerate(producciones_dict):
            if nt in primero:
                grid.SetCellValue(i, 0, nt)
                grid.SetCellValue(i, 1, ', '.join(sorted(primero[nt])))

        self.frame_primero.Add(grid, 1, wx.EXPAND | wx.ALL, 5)
        self.Layout()

    def calcular_siguiente(self, producciones, primero):
        siguiente = defaultdict(set)
        producciones_dict = defaultdict(list)
        for nt, prod in producciones:
            producciones_dict[nt].append(prod)

        start_symbol = list(producciones_dict.keys())[0]
        siguiente[start_symbol].add('$')

        while True:
            updated = False
            for A in producciones_dict:
                for prod in producciones_dict[A]:
                    n = len(prod)
                    for i in range(n):
                        if prod[i].isupper():
                            B = prod[i]
                            beta = prod[i + 1:]
                            primero_beta = self.obtener_primero_beta(beta, primero)
                            antes_actualizacion = len(siguiente[B])
                            siguiente[B].update(primero_beta - {'e'})
                            if 'e' in primero_beta or not beta:
                                siguiente[B].update(siguiente[A])
                            if len(siguiente[B]) > antes_actualizacion:
                                updated = True
            if not updated:
                break

        self.mostrar_siguiente(siguiente, producciones_dict)
        return siguiente

    def obtener_primero_beta(self, beta, primero):
        resultado = set()
        for b in beta:
            if b.isupper():
                resultado.update(primero[b] - {'e'})
                if 'e' not in primero[b]:
                    break
            else:
                resultado.add(b)
                break
        else:
            resultado.add('e')
        return resultado

    def mostrar_siguiente(self, siguiente, producciones_dict):
        for child in self.frame_siguiente.GetChildren():
            child.Destroy()
        grid = wx.grid.Grid(self.panel)
        grid.CreateGrid(len(siguiente), 2)
        grid.SetColLabelValue(0, "V")
        grid.SetColLabelValue(1, "Terminales")

        for i, nt in enumerate(siguiente):
            grid.SetCellValue(i, 0, nt)
            grid.SetCellValue(i, 1, ', '.join(sorted(siguiente[nt])))

        self.frame_siguiente.Add(grid, 1, wx.EXPAND | wx.ALL, 5)
        self.Layout()

    def calcular_tabla_analisis_sintactico(self, producciones, primero, siguiente):
        tabla = defaultdict(lambda: defaultdict(lambda: '--'))
        producciones_dict = defaultdict(list)
        for nt, prod in producciones:
            producciones_dict[nt].append(prod)

        for nt in producciones_dict:
            for prod in producciones_dict[nt]:
                primero_beta = self.obtener_primero_beta(prod, primero)
                for terminal in primero_beta - {'e'}:
                    tabla[nt][terminal] = prod
                if 'e' in primero_beta:
                    for terminal in siguiente[nt]:
                        tabla[nt][terminal] = 'e'

        return tabla

    def mostrar_tabla_analisis_sintactico(self, tabla, no_terminales, terminales):
        for child in self.frame_tabla_analisis_sintactico.GetChildren():
            child.Destroy()
        terminales.append('$')
        terminales.sort()

        grid = wx.grid.Grid(self.panel)
        grid.CreateGrid(len(no_terminales), len(terminales) + 1)
        grid.SetColLabelValue(0, "V")
        for j, t in enumerate(terminales):
            grid.SetColLabelValue(j + 1, t)

        for i, nt in enumerate(no_terminales):
            grid.SetCellValue(i, 0, nt)
            for j, t in enumerate(terminales):
                grid.SetCellValue(i, j + 1, tabla[nt][t])

        self.frame_tabla_analisis_sintactico.Add(grid, 1, wx.EXPAND | wx.ALL, 5)
        self.Layout()

    def on_drop(self, filenames):
        if filenames:
            with open(filenames[0], 'r') as file:
                lines = file.readlines()
            self.process_grammar(lines)

class FileDropTarget(wx.FileDropTarget):
    def __init__(self, window):
        wx.FileDropTarget.__init__(self)
        self.window = window

    def OnDropFiles(self, x, y, filenames):
        self.window.on_drop(filenames)
        return True  # Retornar True para indicar que el evento fue manejado correctamente

if __name__ == "__main__":
    app = wx.App(False)
    frame = MainWindow(None, "Gramática")
    app.MainLoop()
