document.getElementById('file-input').addEventListener('change', handleFileUpload);

function handleFileUpload(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const content = e.target.result;
            document.getElementById('file-content').textContent = content;
            processGrammar(content);
        };
        reader.readAsText(file);
    }
}

function processGrammar(grammarText) {
    const productions = parseProductions(grammarText);
    displayProductions(productions);
    const firstSets = computeFirstSets(productions);
    const followSets = computeFollowSets(productions, firstSets);
    displayFirstAndFollow(firstSets, followSets);
}

function parseProductions(text) {
    const lines = text.split('\n');
    const productions = {};
    lines.forEach(line => {
        const [variable, rules] = line.split(':');
        if (variable && rules) {
            productions[variable.trim()] = rules.split('|').map(rule => rule.trim().split(' '));
        }
    });
    return productions;
}

function displayProductions(productions) {
    const conRecursividadDiv = document.getElementById('con-recursividad');
    conRecursividadDiv.innerHTML = JSON.stringify(productions, null, 2);
}

function computeFirstSets(productions) {
    const firstSets = {};

    // Inicializar firstSets
    for (const variable in productions) {
        firstSets[variable] = new Set();
    }

    // Calcular FIRST
    let changed = true;
    while (changed) {
        changed = false;

        for (const variable in productions) {
            const rules = productions[variable];

            rules.forEach(rule => {
                for (let i = 0; i < rule.length; i++) {
                    const symbol = rule[i];

                    if (isTerminal(symbol)) {
                        if (!firstSets[variable].has(symbol)) {
                            firstSets[variable].add(symbol);
                            changed = true;
                        }
                        break;
                    } else {
                        const firstSet = firstSets[symbol];
                        if (firstSet) {
                            const originalSize = firstSets[variable].size;
                            firstSet.forEach(sym => {
                                if (sym !== 'ε') {
                                    firstSets[variable].add(sym);
                                }
                            });

                            if (originalSize !== firstSets[variable].size) {
                                changed = true;
                            }

                            if (!firstSet.has('ε')) {
                                break;
                            }
                        }
                    }
                }
            });
        }
    }

    return firstSets;
}

function computeFollowSets(productions, firstSets) {
    const followSets = {};

    // Inicializar followSets
    for (const variable in productions) {
        followSets[variable] = new Set();
    }

    // Inicializar followSets para todos los símbolos no terminales
    for (const variable in productions) {
        productions[variable].forEach(rule => {
            rule.forEach(symbol => {
                if (!isTerminal(symbol) && !(symbol in followSets)) {
                    followSets[symbol] = new Set();
                }
            });
        });
    }

    // La entrada inicial contiene el símbolo de inicio
    followSets[Object.keys(productions)[0]].add('$');

    // Calcular FOLLOW
    let changed = true;
    while (changed) {
        changed = false;

        for (const variable in productions) {
            const rules = productions[variable];

            rules.forEach(rule => {
                for (let i = 0; i < rule.length; i++) {
                    const symbol = rule[i];

                    if (!isTerminal(symbol)) {
                        const followSet = followSets[symbol];
                        const originalSize = followSet.size;

                        if (i < rule.length - 1) {
                            const nextSymbol = rule[i + 1];

                            if (isTerminal(nextSymbol)) {
                                followSet.add(nextSymbol);
                            } else {
                                const firstSet = firstSets[nextSymbol];
                                if (firstSet) {
                                    firstSet.forEach(sym => {
                                        if (sym !== 'ε') {
                                            followSet.add(sym);
                                        }
                                    });

                                    if (firstSet.has('ε')) {
                                        followSets[variable].forEach(sym => {
                                            followSet.add(sym);
                                        });
                                    }
                                }
                            }
                        } else {
                            followSets[variable].forEach(sym => {
                                followSet.add(sym);
                            });
                        }

                        if (originalSize !== followSet.size) {
                            changed = true;
                        }
                    }
                }
            });
        }
    }

    return followSets;
}

function isTerminal(symbol) {
    return symbol.startsWith("'") && symbol.endsWith("'");
}

function displayFirstAndFollow(firstSets, followSets) {
    const funcionesDiv = document.getElementById('funciones');
    funcionesDiv.innerHTML = `
        <h3>Función PRIMERO</h3>
        <pre>${JSON.stringify(convertSetsToObject(firstSets), null, 2)}</pre>
        <h3>Función SIGUIENTE</h3>
        <pre>${JSON.stringify(convertSetsToObject(followSets), null, 2)}</pre>
    `;
}

function convertSetsToObject(sets) {
    const obj = {};
    for (const key in sets) {
        obj[key] = Array.from(sets[key]);
    }
    return obj;
}
