import tkinter as tk
from tkinter import filedialog, Text, messagebox
import ply.lex as lex
import ply.yacc as yacc

# Definición del lexer
tokens = (
    'ARROW',
    'PIPE',
    'TERMINAL',
    'VARIABLE',
    'COLON'
)

t_ARROW = r':'
t_PIPE = r'\|'

def t_TERMINAL(t):
    r"'[^']*'"
    return t

def t_VARIABLE(t):
    r'[A-Z]'
    return t

def t_COLON(t):
    r':'
    return t

t_ignore = ' \t\n'

def t_error(t):
    print(f"Caracter ilegal '{t.value[0]}'")
    t.lexer.skip(1)

lexer = lex.lex()

# Función para depurar los tokens generados por el lexer
def print_tokens(data):
    lexer.input(data)
    while True:
        tok = lexer.token()
        if not tok:
            break
        print(tok)

# Definición del parser
start = 'grammar'

def p_grammar(p):
    '''grammar : productions COLON'''
    p[0] = p[1]

def p_productions(p):
    '''productions : productions production
                   | production'''
    if len(p) == 3:
        p[0] = p[1] + [p[2]]
    else:
        p[0] = [p[1]]

def p_production(p):
    '''production : VARIABLE ARROW rules'''
    p[0] = (p[1], p[3])

def p_rules(p):
    '''rules : rules PIPE rule
             | rule'''
    if len(p) == 4:
        p[0] = p[1] + [p[3]]
    else:
        p[0] = [p[1]]

def p_rule(p):
    '''rule : elements'''
    p[0] = p[1]

def p_elements(p):
    '''elements : elements element
                | element'''
    if len(p) == 3:
        p[0] = p[1] + [p[2]]
    else:
        p[0] = [p[1]]

def p_element(p):
    '''element : VARIABLE
               | TERMINAL'''
    p[0] = p[1]

def p_error(p):
    if p:
        print("Error de sintaxis en '%s'" % p.value)
    else:
        print("Error de sintaxis en EOF")

parser = yacc.yacc()

# Funciones de la interfaz gráfica
def load_grammar():
    filepath = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
    if filepath:
        with open(filepath, 'r') as file:
            grammar = file.read()
            display_grammar(grammar)
            parse_grammar(grammar)

def display_grammar(grammar):
    txt_display.delete(1.0, tk.END)
    txt_display.insert(tk.END, grammar)

def parse_grammar(grammar):
    print_tokens(grammar)  # Llamada a la función de depuración para imprimir tokens
    lexer.input(grammar)
    parsed_grammar = parser.parse(grammar, lexer=lexer)
    if parsed_grammar is None:
        messagebox.showerror("Error", "Error de sintaxis en la gramática.")
        return
    productions, terminals = extract_productions_and_terminals(parsed_grammar)
    update_lists(productions, terminals)

def extract_productions_and_terminals(parsed_grammar):
    productions = []
    terminals = set()
    for production in parsed_grammar:
        head, rules = production
        for rule in rules:
            production_str = f"{head} -> {''.join(rule)}"
            productions.append(production_str)
            for element in rule:
                if element.startswith("'") and element.endswith("'"):
                    terminals.add(element.strip("'"))
    return productions, sorted(terminals)

def update_lists(productions, terminals):
    lst_productions.delete(0, tk.END)
    for prod in productions:
        lst_productions.insert(tk.END, prod)

    lst_terminals.delete(0, tk.END)
    for term in terminals:
        lst_terminals.insert(tk.END, term)

# Configuración de la interfaz gráfica
root = tk.Tk()
root.title("Analizador de Gramática")

frame = tk.Frame(root, bg="white")
frame.place(relwidth=1, relheight=1)

btn_load = tk.Button(frame, text="Cargar Gramática", padx=10, pady=5, fg="white", bg="#263D42", command=load_grammar)
btn_load.pack()

txt_display = Text(frame, height=10, padx=10, pady=5)
txt_display.pack()

frame_bottom = tk.Frame(root)
frame_bottom.place(rely=0.6, relwidth=1, relheight=0.4)

lbl_productions = tk.Label(frame_bottom, text="Producciones")
lbl_productions.grid(row=0, column=0, padx=10, pady=5)

lbl_terminals = tk.Label(frame_bottom, text="Terminales")
lbl_terminals.grid(row=0, column=1, padx=10, pady=5)

lst_productions = tk.Listbox(frame_bottom)
lst_productions.grid(row=1, column=0, padx=10, pady=5, sticky='nsew')

lst_terminals = tk.Listbox(frame_bottom)
lst_terminals.grid(row=1, column=1, padx=10, pady=5, sticky='nsew')

root.mainloop()