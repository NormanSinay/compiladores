import tkinter as tk
from tkinter import filedialog
from tkinterdnd2 import DND_FILES, TkinterDnD
from tkinter import ttk
from collections import defaultdict

def cargar_gramatica(file_path=None):
    if not file_path:
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
    if not file_path:
        return

    with open(file_path, 'r') as file:
        lines = file.readlines()

    no_terminales = set()
    terminales = set()
    producciones = []

    for line in lines:
        parts = line.strip().split(':')
        no_terminal = parts[0].strip()
        no_terminales.add(no_terminal)
        prods = parts[1].split('|')
        for prod in prods:
            elementos = prod.split("'")
            produccion_limpia = ''.join([elem if i % 2 == 0 else elem.strip() for i, elem in enumerate(elementos)])
            producciones.append((no_terminal, produccion_limpia))
            for i, elem in enumerate(elementos):
                if i % 2 == 1:
                    terminales.add(elem.strip())

    mostrar_gramatica(list(no_terminales), list(terminales))
    mostrar_texto_original(lines)
    mostrar_producciones(producciones)
    gram_sin_rec = eliminar_recursividad_izquierda(producciones)
    mostrar_gramatica_sin_recursividad(gram_sin_rec)
    calcular_primero(gram_sin_rec)

def mostrar_gramatica(no_terminales, terminales):
    no_terminales.sort()
    terminales.sort()

    for widget in frame_no_terminales.winfo_children():
        widget.destroy()
    for widget in frame_terminales.winfo_children():
        widget.destroy()

    for no_terminal in no_terminales:
        label = tk.Label(frame_no_terminales, text=no_terminal, font=("Helvetica", 14))
        label.pack(anchor='w')

    for terminal in terminales:
        label = tk.Label(frame_terminales, text=terminal, font=("Helvetica", 14))
        label.pack(anchor='w')

def mostrar_texto_original(lines):
    for widget in frame_texto_original.winfo_children():
        widget.destroy()
    for line in lines:
        label = tk.Label(frame_texto_original, text=line.strip(), font=("Helvetica", 14))
        label.pack(anchor='w')

def mostrar_producciones(producciones):
    for widget in frame_producciones.winfo_children():
        widget.destroy()
    for no_terminal, produccion in producciones:
        label = tk.Label(frame_producciones, text=f"{no_terminal} : {produccion}", font=("Helvetica", 14))
        label.pack(anchor='w')

def mostrar_gramatica_sin_recursividad(producciones):
    for widget in frame_sin_recursividad.winfo_children():
        widget.destroy()

    # Crear tabla para mostrar los resultados
    tree_sin_rec = ttk.Treeview(frame_sin_recursividad, columns=("V", "Producciones"), show='headings')
    tree_sin_rec.heading("V", text="V")
    tree_sin_rec.heading("Producciones", text="Producciones")
    tree_sin_rec.column("V", anchor='center', width=100)
    tree_sin_rec.column("Producciones", anchor='center', width=400)
    tree_sin_rec.pack(fill='both', expand=True)

    for no_terminal, produccion in producciones:
        tree_sin_rec.insert('', 'end', values=(no_terminal, produccion.replace("'", "!").replace("ε", "e")))

def eliminar_recursividad_izquierda(producciones):
    no_terminales = sorted(set([prod[0] for prod in producciones]))
    gram_sin_rec = []

    producciones_dict = {nt: [] for nt in no_terminales}
    for nt, prod in producciones:
        producciones_dict[nt].append(prod)

    for i in range(len(no_terminales)):
        Ai = no_terminales[i]
        for j in range(i):
            Aj = no_terminales[j]
            nuevas_producciones = []
            for prod in producciones_dict[Ai]:
                if prod.startswith(Aj):
                    for prod_Aj in producciones_dict[Aj]:
                        nuevas_producciones.append(prod_Aj + prod[len(Aj):])
                else:
                    nuevas_producciones.append(prod)
            producciones_dict[Ai] = nuevas_producciones
        recursivas = [prod for prod in producciones_dict[Ai] if prod.startswith(Ai)]
        no_recursivas = [prod for prod in producciones_dict[Ai] if not prod.startswith(Ai)]
        if recursivas:
            Ai_prime = Ai + "!"
            producciones_dict[Ai] = [prod + Ai_prime for prod in no_recursivas]
            producciones_dict[Ai_prime] = [prod[len(Ai):] + Ai_prime for prod in recursivas] + ['e']
            no_terminales.append(Ai_prime)
            gram_sin_rec.extend([(Ai_prime, prod) for prod in producciones_dict[Ai_prime]])
        gram_sin_rec.extend([(Ai, prod) for prod in producciones_dict[Ai]])

    return gram_sin_rec

def calcular_primero(producciones):
    primero = defaultdict(set)
    producciones_dict = defaultdict(list)
    for nt, prod in producciones:
        producciones_dict[nt].append(prod)

    def obtener_primero(symbol):
        if symbol in primero:
            return primero[symbol]
        if not symbol.isupper():
            primero[symbol].add(symbol)
            return primero[symbol]
        for prod in producciones_dict[symbol]:
            if prod == 'e':
                primero[symbol].add('e')
            else:
                for char in prod:
                    temp = obtener_primero(char)
                    primero[symbol].update(temp - {'e'})
                    if 'e' not in temp:
                        break
                else:
                    primero[symbol].add('e')
        return primero[symbol]

    for nt in list(producciones_dict):
        obtener_primero(nt)

    mostrar_primero(primero, producciones_dict)

def mostrar_primero(primero, producciones_dict):
    for widget in frame_primero.winfo_children():
        widget.destroy()

    # Crear tabla para mostrar los resultados
    tree = ttk.Treeview(frame_primero, columns=("V", "Terminales"), show='headings')
    tree.heading("V", text="V")
    tree.heading("Terminales", text="Terminales")
    tree.column("V", anchor='center', width=100)
    tree.column("Terminales", anchor='center', width=400)
    tree.pack(fill='both', expand=True)

    for nt in producciones_dict:
        if nt in primero:
            tree.insert('', 'end', values=(nt, ', '.join(sorted(primero[nt]))))

def on_drop(event):
    file_path = event.data
    if file_path.startswith('{') and file_path.endswith('}'):
        file_path = file_path[1:-1]
    cargar_gramatica(file_path)

# Configuración de la ventana principal
root = TkinterDnD.Tk()
root.title("Gramática")
root.state('zoomed')

# Configurar el grid para que sea responsivo
root.columnconfigure(0, weight=1)
root.columnconfigure(1, weight=1)
root.columnconfigure(2, weight=1)
root.columnconfigure(3, weight=1)
root.columnconfigure(4, weight=1)
root.columnconfigure(5, weight=1)
root.rowconfigure(0, weight=1)
root.rowconfigure(1, weight=1)
root.rowconfigure(2, weight=1)
root.rowconfigure(3, weight=1)
root.rowconfigure(4, weight=1)

# Encabezados
label_texto_original = tk.Label(root, text="Texto Original", font=("Helvetica", 16))
label_texto_original.grid(row=0, column=0, padx=10, pady=10)

label_no_terminales = tk.Label(root, text="No Terminales", font=("Helvetica", 16))
label_no_terminales.grid(row=0, column=1, padx=10, pady=10)

label_terminales = tk.Label(root, text="Terminales", font=("Helvetica", 16))
label_terminales.grid(row=0, column=2, padx=10, pady=10)

label_producciones = tk.Label(root, text="Producciones", font=("Helvetica", 16))
label_producciones.grid(row=0, column=3, padx=10, pady=10)

# Widgets en la primera fila
frame_texto_original = tk.Frame(root, padx=10, pady=10)
frame_texto_original.grid(row=1, column=0, sticky='nsew')

frame_no_terminales = tk.Frame(root, padx=10, pady=10)
frame_no_terminales.grid(row=1, column=1, sticky='nsew')

frame_terminales = tk.Frame(root, padx=10, pady=10)
frame_terminales.grid(row=1, column=2, sticky='nsew')

frame_producciones = tk.Frame(root, padx=10, pady=10)
frame_producciones.grid(row=1, column=3, sticky='nsew')

# Encabezado para la segunda fila
label_resultado = tk.Label(root, text="Gramática sin Recursividad por la Izquierda", font=("Helvetica", 16))
label_resultado.grid(row=2, column=0, columnspan=6, padx=10, pady=10)

# Frame para la gramática sin recursividad
frame_sin_recursividad = tk.Frame(root, padx=10, pady=10)
frame_sin_recursividad.grid(row=3, column=0, columnspan=3, sticky='nsew')

# Frame y widget para PRIMERO
frame_primero = tk.Frame(root, padx=10, pady=10)
frame_primero.grid(row=3, column=3, columnspan=2, sticky='nsew')

button_cargar = tk.Button(root, text="Cargar Gramática", command=cargar_gramatica, font=("Helvetica", 14))
button_cargar.grid(row=4, column=0, columnspan=6, pady=10)

# Habilitar la funcionalidad de arrastrar y soltar
root.drop_target_register(DND_FILES)
root.dnd_bind('<<Drop>>', on_drop)

root.mainloop()
