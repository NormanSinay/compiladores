import tkinter as tk
from tkinter import filedialog
from tkinterdnd2 import DND_FILES, TkinterDnD
from tkinter import ttk
from collections import defaultdict
from tkinter import font as tkFont

def cargar_gramatica(file_path=None):
    if not file_path:
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
    if not file_path:
        return

    with open(file_path, 'r') as file:
        lines = file.readlines()

    no_terminales = set()
    terminales = set()
    producciones = []

    for line in lines:
        parts = line.strip().split(':')
        no_terminal = parts[0].strip()
        no_terminales.add(no_terminal)
        prods = parts[1].split('|')
        for prod in prods:
            elementos = prod.split("'")
            produccion_limpia = ''.join([elem if i % 2 == 0 else elem.strip() for i, elem in enumerate(elementos)])
            producciones.append((no_terminal, produccion_limpia))
            for i, elem in enumerate(elementos):
                if i % 2 == 1 and elem.strip() != '!' and elem.strip() != 'e':
                    terminales.add(elem.strip())

    mostrar_gramatica(list(no_terminales), list(terminales))
    mostrar_texto_original(lines)
    mostrar_producciones(producciones)
    gram_sin_rec = eliminar_recursividad_izquierda(producciones)
    mostrar_gramatica_sin_recursividad(gram_sin_rec)
    no_terminales_sin_rec, terminales_sin_rec = obtener_gramatica_sin_recursividad(gram_sin_rec)
    mostrar_gramatica_sin_recursividad_vectores(no_terminales_sin_rec, terminales_sin_rec)
    mostrar_gramatica_sin_recursividad_matriz(gram_sin_rec)  # Nueva función para mostrar la matriz
    primero = calcular_primero(gram_sin_rec)
    siguiente = calcular_siguiente(gram_sin_rec, primero)
    tabla_analisis_sintactico = calcular_tabla_analisis_sintactico(gram_sin_rec, primero, siguiente)
    mostrar_tabla_analisis_sintactico(tabla_analisis_sintactico, list(no_terminales), list(terminales))

def obtener_gramatica_sin_recursividad(producciones):
    no_terminales = set()
    terminales = set()
    for nt, prod in producciones:
        no_terminales.add(nt)
        for char in prod:
            if not char.isupper() and char != 'e' and char != '!':
                terminales.add(char)
            elif char == '!':
                terminales.add('e')
    return list(no_terminales), list(terminales)

def configurar_treeview(tree, col_width=100):
    tree.tag_configure('centered', anchor='center')
    for col in tree['columns']:
        tree.column(col, anchor='center', width=col_width)

def mostrar_gramatica_sin_recursividad_vectores(no_terminales, terminales):
    no_terminales.sort()
    terminales.sort()

    for widget in frame_no_terminales_sin_recursividad.winfo_children():
        widget.destroy()
    for widget in frame_terminales_sin_recursividad.winfo_children():
        widget.destroy()

    tree_no_terminales = ttk.Treeview(frame_no_terminales_sin_recursividad, columns=("no_terminales"), show='headings', height=8)
    tree_no_terminales.heading("no_terminales", text="Variables")
    configurar_treeview(tree_no_terminales)
    tree_no_terminales.pack(fill='both', expand=True)
    for no_terminal in no_terminales:
        tree_no_terminales.insert('', 'end', values=(no_terminal,), tags=('centered',))

    tree_terminales = ttk.Treeview(frame_terminales_sin_recursividad, columns=("terminales"), show='headings', height=8)
    tree_terminales.heading("terminales", text="Terminales")
    configurar_treeview(tree_terminales)
    tree_terminales.pack(fill='both', expand=True)
    for terminal in terminales:
        tree_terminales.insert('', 'end', values=(terminal,), tags=('centered',))

def mostrar_gramatica(no_terminales, terminales):
    no_terminales.sort()
    terminales.sort()

    for widget in frame_no_terminales.winfo_children():
        widget.destroy()
    for widget in frame_terminales.winfo_children():
        widget.destroy()

    tree_no_terminales = ttk.Treeview(frame_no_terminales, columns=("no_terminales"), show='headings', height=8)
    tree_no_terminales.heading("no_terminales", text="Variables")
    configurar_treeview(tree_no_terminales)
    tree_no_terminales.pack(fill='both', expand=True)
    for no_terminal in no_terminales:
        tree_no_terminales.insert('', 'end', values=(no_terminal,), tags=('centered',))

    tree_terminales = ttk.Treeview(frame_terminales, columns=("terminales"), show='headings', height=8)
    tree_terminales.heading("terminales", text="Terminales")
    configurar_treeview(tree_terminales)
    tree_terminales.pack(fill='both', expand=True)
    for terminal in terminales:
        tree_terminales.insert('', 'end', values=(terminal,), tags=('centered',))

def mostrar_texto_original(lines):
    for widget in frame_texto_original.winfo_children():
        widget.destroy()

    tree_texto_original = ttk.Treeview(frame_texto_original, columns=("texto_original"), show='headings', height=8)
    tree_texto_original.heading("texto_original", text="Contenido Original")
    configurar_treeview(tree_texto_original, col_width=100)
    tree_texto_original.pack(fill='both', expand=True)
    for line in lines:
        tree_texto_original.insert('', 'end', values=(line.strip(),), tags=('centered',))

def mostrar_producciones(producciones):
    for widget in frame_producciones.winfo_children():
        widget.destroy()

    tree_producciones = ttk.Treeview(frame_producciones, columns=("No Terminal", "Producción"), show='headings', height=8)
    tree_producciones.heading("No Terminal", text="V")
    tree_producciones.heading("Producción", text="Producción")
    configurar_treeview(tree_producciones, col_width=100)
    tree_producciones.pack(fill='both', expand=True)
    for no_terminal, produccion in producciones:
        tree_producciones.insert('', 'end', values=(no_terminal, produccion), tags=('centered',))

def mostrar_gramatica_sin_recursividad(producciones):
    for widget in frame_sin_recursividad.winfo_children():
        widget.destroy()

    tree_sin_recursividad = ttk.Treeview(frame_sin_recursividad, columns=("sin_recursividad"), show='headings', height=8)
    tree_sin_recursividad.heading("sin_recursividad", text="Sin Recursividad")
    configurar_treeview(tree_sin_recursividad, col_width=100)
    tree_sin_recursividad.pack(fill='both', expand=True)
    for no_terminal, produccion in producciones:
        tree_sin_recursividad.insert('', 'end', values=(f"{no_terminal} : {produccion}",), tags=('centered',))

def mostrar_gramatica_sin_recursividad_matriz(producciones):
    for widget in frame_matriz_sin_recursividad.winfo_children():
        widget.destroy()

    label_matriz = tk.Label(frame_matriz_sin_recursividad, text="Producciones Sin Recursividad", font=global_font, bg='#f2f2f2', fg=header_color)
    label_matriz.pack(anchor='center')

    tree_matriz_sin_recursividad = ttk.Treeview(frame_matriz_sin_recursividad, columns=("No Terminal", "Producción"), show='headings', height=8)
    tree_matriz_sin_recursividad.heading("No Terminal", text="V")
    tree_matriz_sin_recursividad.heading("Producción", text="Producción")
    configurar_treeview(tree_matriz_sin_recursividad, col_width=100)
    tree_matriz_sin_recursividad.pack(fill='both', expand=True)
    for no_terminal, produccion in producciones:
        tree_matriz_sin_recursividad.insert('', 'end', values=(no_terminal, produccion), tags=('centered',))

def eliminar_recursividad_izquierda(producciones):
    no_terminales = sorted(set([prod[0] for prod in producciones]))
    gram_sin_rec = []

    producciones_dict = {nt: [] for nt in no_terminales}
    for nt, prod in producciones:
        producciones_dict[nt].append(prod)

    for i in range(len(no_terminales)):
        Ai = no_terminales[i]
        for j in range(i):
            Aj = no_terminales[j]
            nuevas_producciones = []
            for prod in producciones_dict[Ai]:
                if prod.startswith(Aj):
                    for prod_Aj in producciones_dict[Aj]:
                        nuevas_producciones.append(prod_Aj + prod[len(Aj):])
                else:
                    nuevas_producciones.append(prod)
            producciones_dict[Ai] = nuevas_producciones
        recursivas = [prod for prod in producciones_dict[Ai] if prod.startswith(Ai)]
        no_recursivas = [prod for prod in producciones_dict[Ai] if not prod.startswith(Ai)]
        if recursivas:
            Ai_prime = Ai + "!"
            producciones_dict[Ai] = [prod + Ai_prime for prod in no_recursivas]
            producciones_dict[Ai_prime] = [prod[len(Ai):] + Ai_prime for prod in recursivas] + ['e']
            no_terminales.append(Ai_prime)
            gram_sin_rec.extend([(Ai_prime, prod) for prod in producciones_dict[Ai_prime]])
        gram_sin_rec.extend([(Ai, prod) for prod in producciones_dict[Ai]])

    return gram_sin_rec

def calcular_primero(producciones):
    primero = defaultdict(set)
    producciones_dict = defaultdict(list)
    for nt, prod in producciones:
        producciones_dict[nt].append(prod)
    def obtener_primero(symbol):
        if symbol in primero:
            return primero[symbol]
        if not symbol.isupper():
            primero[symbol].add(symbol)
            return primero[symbol]
        for prod in producciones_dict[symbol]:
            if prod == 'e':
                primero[symbol].add('e')
            else:
                for char in prod:
                    temp = obtener_primero(char)
                    primero[symbol].update(temp - {'e'})
                    if 'e' not in temp:
                        break
                else:
                    primero[symbol].add('e')
        return primero[symbol]

    for nt in list(producciones_dict):
        obtener_primero(nt)
    # Mostrar los conjuntos de primero

    for nt in producciones_dict:
        print(f'Primero({nt}): {primero[nt]}')

    mostrar_primero(primero, producciones_dict)
    return primero

def mostrar_primero(primero, producciones_dict):
    for widget in frame_primero.winfo_children():
        widget.destroy()

    label_primero = tk.Label(frame_primero, text="F. Primera", font=global_font, bg='#f2f2f2', fg=header_color)
    label_primero.pack(anchor='center')

    tree_primero = ttk.Treeview(frame_primero, columns=("V", "terminales"), show='headings', height=8)
    tree_primero.heading("V", text="V")
    tree_primero.heading("terminales", text="Terminales")
    configurar_treeview(tree_primero, col_width=100)
    tree_primero.pack(fill='both', expand=True)

    for nt in producciones_dict:
        if nt in primero:
            tree_primero.insert('', 'end', values=(nt, ', '.join(sorted(primero[nt]))), tags=('centered',))
def calcular_siguiente(producciones, primero):
    siguiente = defaultdict(set)
    producciones_dict = defaultdict(list)
    
    # Mapeamos las producciones a un diccionario
    for nt, prod in producciones:
        producciones_dict[nt].append(prod)
    
    # Regla 1: $ en SIGUIENTE del símbolo inicial
    start_symbol = list(producciones_dict.keys())[0]
    siguiente[start_symbol].add('$')
    
    # Repetir hasta que no haya más actualizaciones
    while True:
        updated = False
        for A in producciones_dict:
            for prod in producciones_dict[A]:
                n = len(prod)
                for i in range(n):
                    if prod[i].isupper():  # Si es no terminal
                        B = prod[i]
                        beta = prod[i + 1:]
                        primero_beta = obtener_primero_beta(beta, primero)
                        antes_actualizacion = len(siguiente[B])
                        siguiente[B].update(primero_beta - {'e'})
                        if 'e' in primero_beta:
                            siguiente[B].update(siguiente[A])
                        if len(siguiente[B]) > antes_actualizacion:
                            updated = True
        if not updated:
            break
    
    # Mostrar los conjuntos de siguiente para depuración
    for nt in producciones_dict:
        print(f'Siguiente({nt}): {siguiente[nt]}')

    mostrar_siguiente(siguiente, producciones_dict)
    return siguiente

def obtener_primero_beta(beta, primero):
    resultado = set()
    for b in beta:
        if b.isupper():
            resultado.update(primero[b] - {'e'})
            if 'e' not in primero[b]:
                break
        else:
            resultado.add(b)
            break
    else:
        resultado.add('e')
    return resultado

def mostrar_siguiente(siguiente, producciones_dict):
    for widget in frame_siguiente.winfo_children():
        widget.destroy()

    label_siguiente = tk.Label(frame_siguiente, text="F. Siguiente", font=global_font, bg='#f2f2f2', fg=header_color)
    label_siguiente.pack(anchor='center')

    tree_siguiente = ttk.Treeview(frame_siguiente, columns=("V", "terminales"), show='headings', height=8)
    tree_siguiente.heading("V", text="V")
    tree_siguiente.heading("terminales", text="Terminales")
    configurar_treeview(tree_siguiente, col_width=100)
    tree_siguiente.pack(fill='both', expand=True)

    for nt in producciones_dict:
        if nt in siguiente:
            tree_siguiente.insert('', 'end', values=(nt, ', '.join(sorted(siguiente[nt]))), tags=('centered',))

def calcular_tabla_analisis_sintactico(producciones, primero, siguiente):
    tabla = defaultdict(lambda: defaultdict(lambda: '--'))
    producciones_dict = defaultdict(list)
    for nt, prod in producciones:
        producciones_dict[nt].append(prod)

    for nt in producciones_dict:
        for prod in producciones_dict[nt]:
            primero_beta = obtener_primero_beta(prod, primero)
            for terminal in primero_beta - {'e'}:
                tabla[nt][terminal] = prod
            if 'e' in primero_beta:
                for terminal in siguiente[nt]:
                    tabla[nt][terminal] = 'e'

    return tabla

def mostrar_tabla_analisis_sintactico(tabla, no_terminales, terminales):
    for widget in frame_tabla_analisis_sintactico.winfo_children():
        widget.destroy()

    label_tabla_analisis = tk.Label(frame_tabla_analisis_sintactico, text="Tabla de Análisis Sintáctico", font=global_font, bg='#f2f2f2', fg=header_color)
    label_tabla_analisis.pack(anchor='center')

    tree_tabla_analisis = ttk.Treeview(frame_tabla_analisis_sintactico, columns=["V"] + terminales + ["$"], show='headings', height=8)
    tree_tabla_analisis.heading("V", text="V")
    for terminal in terminales + ["$"]:
        tree_tabla_analisis.heading(terminal, text=terminal)
    configurar_treeview(tree_tabla_analisis, col_width=60)  # Ajuste del ancho de columna
    tree_tabla_analisis.pack(fill='both', expand=True)

    for nt in no_terminales:
        row = [nt] + [tabla[nt][t] for t in terminales + ["$"]]
        tree_tabla_analisis.insert('', 'end', values=row, tags=('centered',))

    for nt in tabla.keys():
        if nt not in no_terminales:
            row = [nt] + [tabla[nt][t] for t in terminales + ["$"]]
            tree_tabla_analisis.insert('', 'end', values=row, tags=('centered',))

def on_drop(event):
    file_path = event.data
    if file_path.startswith('{') and file_path.endswith('}'):
        file_path = file_path[1:-1]
    cargar_gramatica(file_path)

# Configuración de la ventana principal
root = TkinterDnD.Tk()
root.title("Gramática")
root.state('zoomed')
root.config(bg='#f2f2f2')

# Definir una fuente global
global_font = tkFont.Font(family="Helvetica", size=20)
result_font = tkFont.Font(family="Helvetica", size=18)

# Color de encabezado
header_color = '#42948E'

# Configurar el grid para que sea responsivo
root.columnconfigure(0, weight=1, uniform="column")
root.columnconfigure(1, weight=1, uniform="column")
root.columnconfigure(2, weight=1, uniform="column")
root.columnconfigure(3, weight=1, uniform="column")
root.columnconfigure(4, weight=1, uniform="column")
root.columnconfigure(5, weight=1, uniform="column")
root.columnconfigure(6, weight=1, uniform="column")
root.rowconfigure(0, weight=1)
root.rowconfigure(1, weight=1)
root.rowconfigure(2, weight=1)
root.rowconfigure(3, weight=1)
root.rowconfigure(4, weight=1)

style = ttk.Style()
style.configure("Treeview.Heading", font=global_font, foreground=header_color)
style.configure("Treeview", rowheight=30, font=result_font)

# Encabezados
label_texto_original = tk.Label(root, font=global_font, bg='#f2f2f2', fg=header_color)
label_texto_original.grid(row=0, column=0, padx=10, pady=10)

label_no_terminales = tk.Label(root, font=global_font, bg='#f2f2f2', fg=header_color)
label_no_terminales.grid(row=0, column=1, padx=10, pady=10)

label_terminales = tk.Label(root, font=global_font, bg='#f2f2f2', fg=header_color)
label_terminales.grid(row=0, column=2, padx=10, pady=10)

label_producciones = tk.Label(root, font=global_font, bg='#f2f2f2', fg=header_color)
label_producciones.grid(row=0, column=3, padx=10, pady=10)

label_gramatica_sin_recursividad = tk.Label(root, font=global_font, bg='#f2f2f2', fg=header_color)
label_gramatica_sin_recursividad.grid(row=0, column=4, padx=10, pady=10)

label_no_terminales_sin_recursividad = tk.Label(root, font=global_font, bg='#f2f2f2', fg=header_color)
label_no_terminales_sin_recursividad.grid(row=0, column=5, padx=10, pady=10)

label_terminales_sin_recursividad = tk.Label(root, font=global_font, bg='#f2f2f2', fg=header_color)
label_terminales_sin_recursividad.grid(row=0, column=6, padx=10, pady=10)

# Widgets en la primera fila
frame_texto_original = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_texto_original.grid(row=1, column=0, sticky='nsew')

frame_no_terminales = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_no_terminales.grid(row=1, column=1, sticky='nsew')

frame_terminales = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_terminales.grid(row=1, column=2, sticky='nsew')

frame_producciones = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_producciones.grid(row=1, column=3, sticky='nsew')

frame_sin_recursividad = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_sin_recursividad.grid(row=1, column=4, sticky='nsew')

frame_no_terminales_sin_recursividad = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_no_terminales_sin_recursividad.grid(row=1, column=5, sticky='nsew')

frame_terminales_sin_recursividad = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_terminales_sin_recursividad.grid(row=1, column=6, sticky='nsew')

# Encabezado para la segunda fila
label_resultado = tk.Label(root, text="Analizador Sintáctico", font=global_font, bg='#f2f2f2', fg=header_color)
label_resultado.grid(row=2, column=0, columnspan=7, padx=10, pady=10)

# Frame y widget para la matriz de gramática sin recursividad
frame_matriz_sin_recursividad = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_matriz_sin_recursividad.grid(row=3, column=0, columnspan=1, sticky='nsew')

# Frame y widget para PRIMERO
frame_primero = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_primero.grid(row=3, column=1, columnspan=1, sticky='nsew')

# Frame y widget para SIGUIENTE
frame_siguiente = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_siguiente.grid(row=3, column=2, columnspan=1, sticky='nsew')

# Frame y widget para la Tabla de Análisis Sintáctico
frame_tabla_analisis_sintactico = tk.Frame(root, padx=10, pady=10, bg='#f2f2f2')
frame_tabla_analisis_sintactico.grid(row=3, column=3, columnspan=4, sticky='nsew')

button_cargar = tk.Button(root, text="Cargar Gramática", command=cargar_gramatica, font=global_font, bg='#f2f2f2')
button_cargar.grid(row=4, column=0, columnspan=7, pady=10)

# Habilitar la funcionalidad de arrastrar y soltar
root.drop_target_register(DND_FILES)
root.dnd_bind('<<Drop>>', on_drop)

root.mainloop()
