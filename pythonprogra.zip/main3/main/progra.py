import re

def is_upper_case(s):
    return s.isupper()

def is_valid_variable(variable):
    return re.match(r'^[A-Z][^:]*$', variable) is not None

def eliminate_left_recursion(productions):
    non_terminals = list(productions.keys())
    for i in range(len(non_terminals)):
        Ai = non_terminals[i]
        for j in range(i):
            Aj = non_terminals[j]
            new_productions = []
            remaining_productions = []
            for production in productions[Ai]:
                if production.startswith(Aj):
                    gamma = production[len(Aj):].strip()
                    for Aj_production in productions[Aj]:
                        new_productions.append((Aj_production + " " + gamma).strip())
                else:
                    remaining_productions.append(production)
            productions[Ai] = remaining_productions + new_productions
        alpha_productions = []
        beta_productions = []
        for production in productions[Ai]:
            if production.startswith(Ai):
                alpha_productions.append((production[len(Ai):].strip() + " " + Ai + "'").strip())
            else:
                beta_productions.append((production + " " + Ai + "'").strip())
        if alpha_productions:
            productions[Ai] = beta_productions
            productions[Ai + "'"] = alpha_productions + ["ε"]
    return productions

def calculate_first(productions):
    first = {non_terminal: set() for non_terminal in productions}

    def add_first(symbol, value):
        if value not in first[symbol]:
            first[symbol].add(value)
            return True
        return False

    changes = True
    while changes:
        changes = False
        for non_terminal, rules in productions.items():
            for production in rules:
                symbols = re.findall(r"[^ ]+", production)
                for symbol in symbols:
                    if not is_upper_case(symbol):
                        if add_first(non_terminal, symbol):
                            changes = True
                        break
                    else:
                        first_set = first[symbol]
                        epsilon_found = "ε" in first_set
                        for item in first_set:
                            if item != "ε":
                                if add_first(non_terminal, item):
                                    changes = True
                        if not epsilon_found:
                            break
                        elif symbol == symbols[-1]:
                            if add_first(non_terminal, "ε"):
                                changes = True
    return first

def calculate_follow(productions, first_sets):
    follow = {non_terminal: set() for non_terminal in productions}
    follow[list(productions.keys())[0]].add("$")

    changes = True
    while changes:
        changes = False
        for non_terminal, rules in productions.items():
            for production in rules:
                symbols = re.findall(r"[^ ]+", production)
                for i, symbol in enumerate(symbols):
                    if is_upper_case(symbol):
                        next_symbols = symbols[i+1:]
                        next_first = calculate_first_of_string(next_symbols, first_sets)
                        for item in next_first:
                            if item != "ε":
                                if item not in follow[symbol]:
                                    follow[symbol].add(item)
                                    changes = True
                        if "ε" in next_first or not next_symbols:
                            for item in follow[non_terminal]:
                                if item not in follow[symbol]:
                                    follow[symbol].add(item)
                                    changes = True
    return follow

def calculate_first_of_string(symbols, first_sets):
    first = set()
    for symbol in symbols:
        if not is_upper_case(symbol):
            first.add(symbol)
            break
        first_set = first_sets[symbol]
        epsilon_found = "ε" in first_set
        for item in first_set:
            if item != "ε":
                first.add(item)
        if not epsilon_found:
            break
    else:
        first.add("ε")
    return first

def process_grammar(content):
    lines = content.split("\n")
    variables = []
    terminals = []
    productions = {}

    for line in lines:
        if not line.strip():
            continue
        parts = line.split(":")
        if len(parts) != 2:
            continue
        variable = parts[0].strip()
        if not is_valid_variable(variable):
            continue
        if variable not in variables:
            variables.append(variable)

        content_inside_quotes = re.findall(r"'([^']+)'", parts[1])
        for item in content_inside_quotes:
            if item not in terminals:
                terminals.append(item)

        productions_array = [v.strip().replace("'", "") for v in parts[1].split("|")]
        productions[variable] = productions_array

    updated_productions = eliminate_left_recursion(productions)
    first_sets = calculate_first(updated_productions)
    follow_sets = calculate_follow(updated_productions, first_sets)

    return variables, terminals, productions, updated_productions, first_sets, follow_sets

def display_results(variables, terminals, original_content, productions, updated_productions, first_sets, follow_sets):
    print("\nVariables:")
    print("\n".join(variables))
    
    print("\nTerminales:")
    print("\n".join(terminals))
    
    print("\nProducciones Originales:")
    for var, prods in productions.items():
        print(f"{var} : {' | '.join(prods)}")
    
    print("\nProducciones Sin Recursividad:")
    for var, prods in updated_productions.items():
        print(f"{var} : {' | '.join(prods)}")
    
    print("\nFunción PRIMERO:")
    for var, first in first_sets.items():
        print(f"FIRST({var}) = {{ {', '.join(first)} }}")
    
    print("\nFunción SIGUIENTE:")
    for var, follow in follow_sets.items():
        print(f"FOLLOW({var}) = {{ {', '.join(follow)} }}")

# Ejemplo de uso
with open("grammar.txt", "r") as file:
    content = file.read()

variables, terminals, original_productions, updated_productions, first_sets, follow_sets = process_grammar(content)
display_results(variables, terminals, content, original_productions, updated_productions, first_sets, follow_sets)